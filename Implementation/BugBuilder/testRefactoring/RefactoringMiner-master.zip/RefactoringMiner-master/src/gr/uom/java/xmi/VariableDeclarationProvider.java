package gr.uom.java.xmi;

import gr.uom.java.xmi.decomposition.VariableDeclaration;

public interface VariableDeclarationProvider {
	public VariableDeclaration getVariableDeclaration();
}
