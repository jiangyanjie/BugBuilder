package org.refactoringminer.api;

public class RefactoringMinerTimedOutException extends Exception {

}
